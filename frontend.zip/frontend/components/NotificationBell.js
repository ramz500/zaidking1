import { useEffect, useState } from 'react';
import { useSelector } from 'react-redux';
import io from 'socket.io-client';
import axios from 'axios';

export default function NotificationBell() {
  const [notifications, setNotifications] = useState([]);
  const [showDropdown, setShowDropdown] = useState(false);
  const user = useSelector(state => state.auth.user);

  useEffect(() => {
    if (!user) return;
    // دریافت اعلان‌های قبلی
    axios.get('/api/notifications').then(res => setNotifications(res.data));

    const socket = io(process.env.NEXT_PUBLIC_SOCKET_URL, {
      auth: { token: localStorage.getItem('accessToken') }
    });
    socket.on('notification', (data) => {
      setNotifications(prev => [data, ...prev]);
      // پخش صدا یا نمایش توست
    });
    return () => socket.disconnect();
  }, [user]);

  const markAsRead = async (id) => {
    await axios.post(`/api/notifications/${id}/read`);
    setNotifications(prev => prev.map(n => n.id === id ? { ...n, isRead: true } : n));
  };

  return (
    <div className="relative">
      <button onClick={() => setShowDropdown(!showDropdown)} className="relative">
        🔔
        {notifications.filter(n => !n.isRead).length > 0 && (
          <span className="absolute top-0 right-0 bg-red-600 text-xs rounded-full px-1">
            {notifications.filter(n => !n.isRead).length}
          </span>
        )}
      </button>
      {showDropdown && (
        <div className="absolute right-0 mt-2 w-64 bg-gray-900 border border-gray-700 rounded shadow-lg">
          {notifications.length === 0 ? (
            <p className="p-2 text-gray-400">هیچ اعلانی وجود ندارد</p>
          ) : (
            notifications.slice(0, 5).map(n => (
              <div key={n.id} className={`p-2 border-b border-gray-800 ${n.isRead ? 'opacity-50' : ''}`}>
                <p className="text-sm">{n.content}</p>
                {!n.isRead && (
                  <button onClick={() => markAsRead(n.id)} className="text-xs text-blue-400 mt-1">
                    علامت‌گذاری به عنوان خوانده شده
                  </button>
                )}
              </div>
            ))
          )}
        </div>
      )}
    </div>
  );
}