import { motion, AnimatePresence } from 'framer-motion';

export default function WinnerAnimation({ winner, competitionTitle }) {
  return (
    <AnimatePresence>
      <motion.div
        initial={{ scale: 0, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        exit={{ scale: 0, opacity: 0 }}
        className="fixed top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 bg-gradient-to-r from-purple-900 to-red-900 p-8 rounded-lg shadow-2xl z-50 text-center border-4 border-yellow-500"
      >
        <h2 className="text-3xl font-bold text-yellow-300 mb-4">🏆 برنده مسابقه 🏆</h2>
        <p className="text-2xl text-white">{competitionTitle}</p>
        <div className="mt-4">
          <img src={winner.avatar || '/default-avatar.png'} className="w-24 h-24 rounded-full mx-auto border-4 border-yellow-500" />
          <p className="text-4xl font-bold text-white mt-2">{winner.username}</p>
        </div>
        <motion.button
          whileHover={{ scale: 1.1 }}
          className="mt-6 bg-green-600 text-white px-6 py-2 rounded-full text-xl"
          onClick={() => alert('تبریک گفتید!')}
        >
          🎉 تبریک 🎉
        </motion.button>
      </motion.div>
    </AnimatePresence>
  );
}