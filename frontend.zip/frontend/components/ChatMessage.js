import React from 'react';

const ChatMessage = ({ message }) => {
  const { sender, content, type, fileUrl } = message;
  return (
    <div className="flex items-start space-x-2">
      <img src={sender.avatar || '/default-avatar.png'} className="w-8 h-8 rounded-full" />
      <div>
        <span className="text-red-500 font-bold">{sender.username}</span>
        <div className="bg-gray-800 p-2 rounded mt-1">
          {type === 'text' && <p>{content}</p>}
          {type === 'image' && <img src={fileUrl} className="max-w-xs rounded" />}
          {type === 'audio' && <audio controls src={fileUrl} />}
          {type === 'file' && <a href={fileUrl} target="_blank" className="text-blue-400">دانلود فایل</a>}
        </div>
      </div>
    </div>
  );
};

export default ChatMessage;