import { useState } from 'react';
import axios from 'axios';

export default function ReportButton({ targetType, targetId }) {
  const [showForm, setShowForm] = useState(false);
  const [reason, setReason] = useState('');

  const submitReport = async () => {
    await axios.post('/api/reports', { reason, targetType, targetId });
    alert('گزارش شما ثبت شد.');
    setShowForm(false);
  };

  return (
    <>
      <button onClick={() => setShowForm(true)} className="text-red-500 text-sm">🚩 گزارش</button>
      {showForm && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center">
          <div className="bg-gray-900 p-6 rounded w-96">
            <h3 className="text-xl mb-4">گزارش تخلف</h3>
            <textarea
              value={reason}
              onChange={(e) => setReason(e.target.value)}
              className="w-full p-2 bg-gray-800 rounded mb-4"
              placeholder="دلیل گزارش را بنویسید..."
            />
            <div className="flex justify-end space-x-2">
              <button onClick={() => setShowForm(false)} className="px-4 py-2 bg-gray-700 rounded">انصراف</button>
              <button onClick={submitReport} className="px-4 py-2 bg-red-700 rounded">ارسال</button>
            </div>
          </div>
        </div>
      )}
    </>
  );
}