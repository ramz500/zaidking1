import { useEffect, useRef, useState } from 'react';
import { Device } from 'mediasoup-client';
import io from 'socket.io-client';

let socket;
let device;
let sendTransport;
let recvTransport;
let localStream;

export default function VoiceRoom({ roomId }) {
  const [participants, setParticipants] = useState([]);
  const audioRefs = useRef({});

  useEffect(() => {
    socket = io(process.env.NEXT_PUBLIC_SOCKET_URL, {
      auth: { token: localStorage.getItem('accessToken') }
    });

    socket.emit('joinVoiceRoom', { roomId }, async (data) => {
      if (data.error) return console.error(data.error);
      const { routerRtpCapabilities, transportOptions } = data;

      device = new Device();
      await device.load({ routerRtpCapabilities });

      // ایجاد transport ارسال
      sendTransport = device.createSendTransport(transportOptions);

      sendTransport.on('connect', ({ dtlsParameters }, callback, errback) => {
        socket.emit('connectTransport', {
          transportId: sendTransport.id,
          dtlsParameters
        }, (response) => {
          if (response.error) errback(response.error);
          else callback();
        });
      });

      sendTransport.on('produce', ({ kind, rtpParameters }, callback, errback) => {
        socket.emit('produce', { kind, rtpParameters }, (response) => {
          if (response.error) errback(response.error);
          else callback({ id: response.id });
        });
      });

      // دریافت صدا از میکروفون
      localStream = await navigator.mediaDevices.getUserMedia({ audio: true });
      const audioTrack = localStream.getAudioTracks()[0];
      await sendTransport.produce({ track: audioTrack });

      // ایجاد transport دریافت
      recvTransport = device.createRecvTransport(transportOptions);
      recvTransport.on('connect', ({ dtlsParameters }, callback, errback) => {
        socket.emit('connectTransport', {
          transportId: recvTransport.id,
          dtlsParameters
        }, (response) => {
          if (response.error) errback(response.error);
          else callback();
        });
      });
    });

    socket.on('newProducer', async ({ producerId, userId, kind }) => {
      // مصرف producer جدید
      socket.emit('consume', { producerId, rtpCapabilities: device.rtpCapabilities }, async (data) => {
        if (data.error) return console.error(data.error);
        const consumer = await recvTransport.consume(data);
        const audioEl = new Audio();
        audioEl.srcObject = new MediaStream([consumer.track]);
        audioEl.play();
        audioRefs.current[userId] = audioEl;
        setParticipants(prev => [...prev, userId]);
      });
    });

    socket.on('peerLeft', ({ userId }) => {
      if (audioRefs.current[userId]) {
        audioRefs.current[userId].pause();
        delete audioRefs.current[userId];
      }
      setParticipants(prev => prev.filter(id => id !== userId));
    });

    return () => {
      socket.emit('leaveVoiceRoom');
      localStream?.getTracks().forEach(t => t.stop());
    };
  }, [roomId]);

  return (
    <div>
      <h3>اتاق صوتی - {roomId}</h3>
      <p>شرکت‌کنندگان: {participants.length}</p>
    </div>
  );
}