import { useState, useEffect } from 'react';
import { useSelector } from 'react-redux';
import axios from 'axios';
import { useRouter } from 'next/router';

export default function Competitions() {
  const [competitions, setCompetitions] = useState([]);
  const [newComp, setNewComp] = useState({ title: '', description: '', endTime: '', criteria: 'votes' });
  const user = useSelector((state) => state.auth.user);

  useEffect(() => {
    fetchCompetitions();
  }, []);

  const fetchCompetitions = async () => {
    const res = await axios.get('/api/competitions');
    setCompetitions(res.data);
  };

  const createCompetition = async (e) => {
    e.preventDefault();
    await axios.post('/api/competitions', newComp);
    fetchCompetitions();
  };

  return (
    <div className="min-h-screen bg-dark text-white p-8">
      <h1 className="text-3xl font-bold mb-6">مسابقات</h1>
      {user && (
        <form onSubmit={createCompetition} className="bg-gray-900 p-4 rounded mb-6">
          <h2 className="text-xl mb-4">ایجاد مسابقه جدید</h2>
          <input
            placeholder="عنوان"
            value={newComp.title}
            onChange={(e) => setNewComp({ ...newComp, title: e.target.value })}
            className="w-full p-2 mb-2 bg-gray-800 rounded"
            required
          />
          <textarea
            placeholder="توضیحات"
            value={newComp.description}
            onChange={(e) => setNewComp({ ...newComp, description: e.target.value })}
            className="w-full p-2 mb-2 bg-gray-800 rounded"
          />
          <input
            type="datetime-local"
            value={newComp.endTime}
            onChange={(e) => setNewComp({ ...newComp, endTime: e.target.value })}
            className="w-full p-2 mb-2 bg-gray-800 rounded"
            required
          />
          <select
            value={newComp.criteria}
            onChange={(e) => setNewComp({ ...newComp, criteria: e.target.value })}
            className="w-full p-2 mb-2 bg-gray-800 rounded"
          >
            <option value="votes">بیشترین رأی</option>
            <option value="reactions">بیشترین ری‌اکشن</option>
            <option value="interactions">بیشترین تعامل</option>
          </select>
          <button type="submit" className="bg-red-700 px-4 py-2 rounded">ایجاد</button>
        </form>
      )}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {competitions.map((comp) => (
          <div key={comp.id} className="bg-gray-900 p-4 rounded">
            <h3 className="text-xl font-bold">{comp.title}</h3>
            <p className="text-gray-400">{comp.description}</p>
            <p>پایان: {new Date(comp.endTime).toLocaleString()}</p>
            <p>وضعیت: {comp.status}</p>
            {comp.winner && <p>برنده: {comp.winner.username}</p>}
          </div>
        ))}
      </div>
    </div>
  );
}