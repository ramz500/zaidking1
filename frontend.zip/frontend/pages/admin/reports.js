import { useEffect, useState } from 'react';
import axios from 'axios';

export default function AdminReports() {
  const [reports, setReports] = useState([]);

  useEffect(() => {
    fetchReports();
  }, []);

  const fetchReports = async () => {
    const res = await axios.get('/api/reports');
    setReports(res.data);
  };

  const updateStatus = async (id, status) => {
    await axios.put(`/api/reports/${id}`, { status });
    fetchReports();
  };

  return (
    <div className="p-4">
      <h1 className="text-2xl mb-4">گزارش‌های تخلف</h1>
      <table className="w-full bg-gray-900">
        <thead>
          <tr>
            <th>ID</th>
            <th>نوع</th>
            <th>هدف</th>
            <th>گزارش‌دهنده</th>
            <th>دلیل</th>
            <th>وضعیت</th>
            <th>عملیات</th>
          </tr>
        </thead>
        <tbody>
          {reports.map(r => (
            <tr key={r.id}>
              <td>{r.id}</td>
              <td>{r.targetType}</td>
              <td>{r.targetId}</td>
              <td>{r.reporter?.username}</td>
              <td>{r.reason.substring(0, 30)}...</td>
              <td>{r.status}</td>
              <td>
                <select onChange={(e) => updateStatus(r.id, e.target.value)} value={r.status}>
                  <option value="pending">در انتظار</option>
                  <option value="reviewed">بررسی‌شده</option>
                  <option value="resolved">حل‌شده</option>
                </select>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}