import { useEffect, useState } from 'react';
import axios from 'axios';
import { useRouter } from 'next/router';
import { useSelector } from 'react-redux';

export default function AdminDashboard() {
  const [users, setUsers] = useState([]);
  const [stats, setStats] = useState({});
  const user = useSelector((state) => state.auth.user);
  const router = useRouter();

  useEffect(() => {
    if (user?.role !== 'admin') {
      router.push('/');
      return;
    }
    fetchData();
  }, []);

  const fetchData = async () => {
    const usersRes = await axios.get('/api/admin/users');
    const statsRes = await axios.get('/api/admin/stats');
    setUsers(usersRes.data);
    setStats(statsRes.data);
  };

  const banUser = async (userId) => {
    await axios.post(`/api/admin/ban/${userId}`);
    fetchData();
  };

  return (
    <div className="min-h-screen bg-dark text-white p-8">
      <h1 className="text-3xl font-bold mb-6">پنل مدیریت</h1>
      <div className="grid grid-cols-3 gap-4 mb-8">
        <div className="bg-gray-900 p-4 rounded">کاربران آنلاین: {stats.onlineUsers}</div>
        <div className="bg-gray-900 p-4 rounded">تعداد اتاق‌ها: {stats.rooms}</div>
        <div className="bg-gray-900 p-4 rounded">مسابقات فعال: {stats.activeCompetitions}</div>
      </div>
      <h2 className="text-2xl mb-4">مدیریت کاربران</h2>
      <table className="w-full bg-gray-900 rounded">
        <thead>
          <tr className="border-b border-gray-700">
            <th className="p-2 text-left">ID</th>
            <th className="p-2 text-left">نام کاربری</th>
            <th className="p-2 text-left">ایمیل</th>
            <th className="p-2 text-left">نقش</th>
            <th className="p-2 text-left">وضعیت</th>
            <th className="p-2 text-left">عملیات</th>
          </tr>
        </thead>
        <tbody>
          {users.map((u) => (
            <tr key={u.id} className="border-b border-gray-800">
              <td className="p-2">{u.id}</td>
              <td className="p-2">{u.username}</td>
              <td className="p-2">{u.email}</td>
              <td className="p-2">{u.role}</td>
              <td className="p-2">{u.status}</td>
              <td className="p-2">
                <button onClick={() => banUser(u.id)} className="bg-red-700 px-2 py-1 rounded text-sm">
                  بن
                </button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}