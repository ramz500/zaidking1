import { useState } from 'react';
import { useDispatch } from 'react-redux';
import { login, register } from '../store/authSlice';
import { useRouter } from 'next/router';

export default function Home() {
  const [isLogin, setIsLogin] = useState(true);
  const [form, setForm] = useState({ username: '', password: '', email: '' });
  const [recoveryCode, setRecoveryCode] = useState('');
  const dispatch = useDispatch();
  const router = useRouter();

  const handleChange = (e) => setForm({ ...form, [e.target.name]: e.target.value });

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (isLogin) {
      const res = await dispatch(login(form));
      if (!res.error) router.push('/chat');
    } else {
      const res = await dispatch(register(form));
      if (res.payload?.recoveryCode) setRecoveryCode(res.payload.recoveryCode);
      else router.push('/chat');
    }
  };

  return (
    <div className="min-h-screen bg-dark flex items-center justify-center">
      <div className="bg-gray-900 p-8 rounded-lg shadow-2xl w-96">
        <h1 className="text-3xl text-white font-bold mb-6 text-center">ShadowVerse</h1>
        {recoveryCode && (
          <div className="bg-red-900 border border-red-700 text-white p-4 rounded mb-4">
            <p className="font-bold">کد بازیابی شما (آن را ذخیره کنید):</p>
            <p className="text-xl text-center">{recoveryCode}</p>
          </div>
        )}
        <form onSubmit={handleSubmit}>
          <input
            name="username"
            placeholder="نام کاربری"
            value={form.username}
            onChange={handleChange}
            className="w-full p-3 mb-4 bg-gray-800 text-white rounded border border-gray-700"
            required
          />
          <input
            name="password"
            type="password"
            placeholder="رمز عبور"
            value={form.password}
            onChange={handleChange}
            className="w-full p-3 mb-4 bg-gray-800 text-white rounded border border-gray-700"
            required
          />
          {!isLogin && (
            <input
              name="email"
              type="email"
              placeholder="ایمیل (اختیاری)"
              value={form.email}
              onChange={handleChange}
              className="w-full p-3 mb-4 bg-gray-800 text-white rounded border border-gray-700"
            />
          )}
          <button
            type="submit"
            className="w-full bg-red-700 hover:bg-red-800 text-white font-bold py-3 rounded transition"
          >
            {isLogin ? 'ورود' : 'ثبت‌نام'}
          </button>
        </form>
        <p className="text-gray-400 text-center mt-4">
          {isLogin ? 'حساب ندارید؟' : 'قبلاً ثبت‌نام کرده‌اید؟'}
          <button
            onClick={() => setIsLogin(!isLogin)}
            className="text-red-500 hover:underline ml-2"
          >
            {isLogin ? 'ثبت‌نام' : 'ورود'}
          </button>
        </p>
      </div>
    </div>
  );
}