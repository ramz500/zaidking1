import { useEffect, useState } from 'react';
import { useRouter } from 'next/router';
import axios from 'axios';
import { useSelector } from 'react-redux';

export default function Profile() {
  const router = useRouter();
  const { id } = router.query;
  const [user, setUser] = useState(null);
  const currentUser = useSelector((state) => state.auth.user);

  useEffect(() => {
    if (id) {
      axios.get(`/api/users/${id}`).then((res) => setUser(res.data));
    }
  }, [id]);

  if (!user) return <div>Loading...</div>;

  return (
    <div className="min-h-screen bg-dark text-white p-8">
      <div className="max-w-2xl mx-auto bg-gray-900 rounded-lg p-6">
        <div className="flex items-center space-x-4">
          <img src={user.avatar || '/default-avatar.png'} className="w-24 h-24 rounded-full border-2 border-red-600" />
          <div>
            <h1 className="text-3xl font-bold">{user.username}</h1>
            <p className="text-gray-400">سطح {user.level} • {user.xp} XP</p>
            <p className="mt-2">{user.bio || 'این کاربر هنوز بیوگرافی ننوشته است.'}</p>
          </div>
        </div>
        <div className="mt-6">
          <h2 className="text-xl font-bold text-red-500 mb-2">نشان‌ها</h2>
          <div className="flex space-x-2">
            {user.badges?.map((badge) => (
              <div key={badge.id} className="bg-gray-800 p-2 rounded" title={badge.description}>
                {badge.name}
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}