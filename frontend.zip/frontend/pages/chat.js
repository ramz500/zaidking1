import { useEffect, useState, useRef } from 'react';
import { useSelector } from 'react-redux';
import io from 'socket.io-client';
import { useRouter } from 'next/router';
import ChatMessage from '../components/ChatMessage';
import { useGetMessagesQuery } from '../store/api';

let socket;

export default function Chat() {
  const [messages, setMessages] = useState([]);
  const [input, setInput] = useState('');
  const user = useSelector((state) => state.auth.user);
  const router = useRouter();
  const messagesEndRef = useRef(null);

  const { data: initialMessages } = useGetMessagesQuery({ roomId: 'global' });

  useEffect(() => {
    if (!user) {
      router.push('/');
      return;
    }

    socket = io(process.env.NEXT_PUBLIC_SOCKET_URL, {
      auth: { token: localStorage.getItem('accessToken') }
    });

    socket.on('globalMessage', (message) => {
      setMessages((prev) => [...prev, message]);
    });

    socket.on('privateMessage', (message) => {
      setMessages((prev) => [...prev, message]);
    });

    return () => socket.disconnect();
  }, [user]);

  useEffect(() => {
    if (initialMessages) setMessages(initialMessages);
  }, [initialMessages]);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  const sendMessage = (e) => {
    e.preventDefault();
    if (input.trim()) {
      socket.emit('sendGlobalMessage', { content: input });
      setInput('');
    }
  };

  return (
    <div className="flex h-screen bg-dark text-white">
      {/* سایدبار (لیست اتاق‌ها، دوستان و ...) */}
      <div className="w-64 bg-gray-900 border-r border-gray-800 p-4">
        <h2 className="text-xl font-bold text-red-600 mb-4">اتاق‌ها</h2>
        <div className="space-y-2">
          <div className="bg-gray-800 p-2 rounded cursor-pointer hover:bg-gray-700">عمومی</div>
        </div>
      </div>

      {/* بخش اصلی چت */}
      <div className="flex-1 flex flex-col">
        <div className="flex-1 overflow-y-auto p-4 space-y-2">
          {messages.map((msg) => (
            <ChatMessage key={msg.id} message={msg} />
          ))}
          <div ref={messagesEndRef} />
        </div>
        <form onSubmit={sendMessage} className="bg-gray-900 p-4 flex">
          <input
            type="text"
            value={input}
            onChange={(e) => setInput(e.target.value)}
            className="flex-1 p-2 bg-gray-800 text-white rounded-l border border-gray-700 focus:outline-none"
            placeholder="پیام خود را بنویسید..."
          />
          <button type="submit" className="bg-red-700 hover:bg-red-800 px-6 py-2 rounded-r">
            ارسال
          </button>
        </form>
      </div>
    </div>
  );
}