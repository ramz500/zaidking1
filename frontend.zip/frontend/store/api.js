import { createApi, fetchBaseQuery } from '@reduxjs/toolkit/query/react';

const baseQuery = fetchBaseQuery({
  baseUrl: process.env.NEXT_PUBLIC_API_URL,
  prepareHeaders: (headers) => {
    const token = localStorage.getItem('accessToken');
    if (token) headers.set('authorization', `Bearer ${token}`);
    return headers;
  }
});

export const api = createApi({
  reducerPath: 'api',
  baseQuery,
  endpoints: (builder) => ({
    getMessages: builder.query({
      query: ({ roomId, recipientId }) => ({
        url: '/chat/messages',
        params: { roomId, recipientId }
      })
    }),
    // سایر endpoints
  })
});

export const { useGetMessagesQuery } = api;