function testAPI() {
  fetch("/api/test")
    .then(res => res.json())
    .then(data => {
      document.getElementById("status").innerText = data.message;
    })
    .catch(err => {
      document.getElementById("status").innerText = "Server not responding ❌";
      console.error(err);
    });
}