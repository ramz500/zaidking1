const Report = require('../models/Report');
const User = require('../models/User');
const { sendReportEmail } = require('../config/email');

// ایجاد گزارش جدید
exports.createReport = async (req, res) => {
  try {
    const { reason, targetType, targetId } = req.body;

    // اعتبارسنجی ساده
    if (!reason || !targetType || !targetId) {
      return res.status(400).json({ error: 'تمامی فیلدها الزامی هستند' });
    }

    const reporter = await User.findByPk(req.userId);
    let targetUsername = '';
    if (targetType === 'user') {
      const target = await User.findByPk(targetId);
      targetUsername = target ? target.username : 'نامشخص';
    }

    const report = await Report.create({
      reason,
      targetType,
      targetId,
      reporterId: req.userId,
      status: 'pending'
    });

    // ارسال ایمیل به ادمین (اجرا در پس‌زمینه)
    sendReportEmail({
      reason,
      targetType,
      targetId,
      reporterUsername: reporter.username,
      targetUsername
    }).catch(err => console.error('Email send failed:', err));

    res.status(201).json({
      message: 'گزارش شما ثبت شد و به ادمین ارسال گردید.',
      reportId: report.id
    });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'خطای سرور' });
  }
};

// دریافت لیست گزارش‌ها (فقط ادمین)
exports.getReports = async (req, res) => {
  try {
    const reports = await Report.findAll({
      include: [
        { model: User, as: 'reporter', attributes: ['id', 'username', 'avatar'] }
      ],
      order: [['createdAt', 'DESC']]
    });
    res.json(reports);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

// به‌روزرسانی وضعیت گزارش (فقط ادمین)
exports.updateReportStatus = async (req, res) => {
  try {
    const { id } = req.params;
    const { status, adminAction } = req.body;
    const report = await Report.findByPk(id);
    if (!report) {
      return res.status(404).json({ error: 'گزارش یافت نشد' });
    }
    report.status = status;
    if (adminAction) report.adminAction = adminAction;
    await report.save();
    res.json({ message: 'وضعیت گزارش به‌روزرسانی شد' });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};