const User = require('../models/User');
const Message = require('../models/Message');
const { addXP } = require('../utils/levelSystem');

// دریافت پروفایل کاربر جاری
exports.getMe = async (req, res) => {
  try {
    const user = await User.findByPk(req.userId, {
      attributes: { exclude: ['password', 'twoFactorSecret', 'recoveryCode'] }
    });
    res.json(user);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

// دریافت پروفایل یک کاربر با نام کاربری
exports.getUserByUsername = async (req, res) => {
  try {
    const { username } = req.params;
    const user = await User.findOne({
      where: { username },
      attributes: ['id', 'username', 'avatar', 'bio', 'level', 'xp', 'status', 'lastSeen', 'inviteCount', 'role']
    });
    if (!user) return res.status(404).json({ error: 'کاربر یافت نشد' });
    res.json(user);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

// بروزرسانی پروفایل
exports.updateProfile = async (req, res) => {
  try {
    const { bio, avatar } = req.body;
    const user = await User.findByPk(req.userId);
    if (bio !== undefined) user.bio = bio;
    if (avatar !== undefined) user.avatar = avatar;
    await user.save();
    res.json({ message: 'پروفایل بروزرسانی شد', user });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

// تغییر رمز عبور
exports.changePassword = async (req, res) => {
  try {
    const { oldPassword, newPassword } = req.body;
    const user = await User.findByPk(req.userId);
    if (!(await user.comparePassword(oldPassword))) {
      return res.status(401).json({ error: 'رمز عبور فعلی نادرست است' });
    }
    user.password = newPassword; // hook beforeUpdate هش می‌کند
    await user.save();
    res.json({ message: 'رمز عبور با موفقیت تغییر کرد' });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

// حذف حساب کاربری
exports.deleteAccount = async (req, res) => {
  try {
    const userId = req.userId;
    // حذف همه پیام‌های مرتبط
    await Message.destroy({ where: { senderId: userId } });
    await Message.destroy({ where: { recipientId: userId } });
    // حذف کاربر
    await User.destroy({ where: { id: userId } });
    res.json({ message: 'حساب کاربری و تمام پیام‌ها با موفقیت حذف شدند.' });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

// دریافت کد دعوت کاربر
exports.getReferralCode = async (req, res) => {
  try {
    const user = await User.findByPk(req.userId);
    res.json({ referralCode: user.referralCode, inviteCount: user.inviteCount });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};