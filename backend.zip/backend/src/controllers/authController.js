const User = require('../models/User');
const jwt = require('jsonwebtoken');
const speakeasy = require('speakeasy');
const QRCode = require('qrcode');
const { Op } = require('sequelize');
const { generateTokens } = require('../utils/token');

exports.register = async (req, res) => {
  try {
    const { username, password, email } = req.body;
    const existing = await User.findOne({ where: { [Op.or]: [{ username }, { email }] } });
    if (existing) return res.status(400).json({ error: 'Username or email already exists' });

    const user = await User.create({ username, password, email });
    const { accessToken, refreshToken } = generateTokens(user);

    res.status(201).json({
      message: 'User created',
      recoveryCode: user.recoveryCode,
      accessToken,
      refreshToken
    });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

exports.login = async (req, res) => {
  try {
    const { username, password } = req.body;
    const user = await User.findOne({ where: { username } });
    if (!user || !(await user.comparePassword(password))) {
      return res.status(401).json({ error: 'Invalid credentials' });
    }

    if (user.twoFactorEnabled) {
      const tempToken = jwt.sign({ id: user.id, step: '2fa' }, process.env.JWT_SECRET, { expiresIn: '5m' });
      return res.json({ require2fa: true, tempToken });
    }

    const { accessToken, refreshToken } = generateTokens(user);
    res.json({ accessToken, refreshToken });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

exports.verify2FA = async (req, res) => {
  try {
    const { tempToken, token } = req.body;
    const decoded = jwt.verify(tempToken, process.env.JWT_SECRET);
    if (decoded.step !== '2fa') return res.status(401).json({ error: 'Invalid token' });

    const user = await User.findByPk(decoded.id);
    if (!user) return res.status(404).json({ error: 'User not found' });

    const verified = speakeasy.totp.verify({
      secret: user.twoFactorSecret,
      encoding: 'base32',
      token
    });

    if (!verified) return res.status(401).json({ error: 'Invalid 2FA code' });

    const { accessToken, refreshToken } = generateTokens(user);
    res.json({ accessToken, refreshToken });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

exports.enable2FA = async (req, res) => {
  try {
    const user = await User.findByPk(req.userId);
    const secret = speakeasy.generateSecret({ length: 20 });
    user.twoFactorSecret = secret.base32;
    await user.save();

    const otpauth = speakeasy.otpauthURL({ secret: secret.ascii, label: `ShadowVerse:${user.username}` });
    QRCode.toDataURL(otpauth, (err, dataUrl) => {
      res.json({ secret: secret.base32, qrCode: dataUrl });
    });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

exports.verifyEnable2FA = async (req, res) => {
  try {
    const { token } = req.body;
    const user = await User.findByPk(req.userId);
    const verified = speakeasy.totp.verify({ secret: user.twoFactorSecret, encoding: 'base32', token });
    if (!verified) return res.status(400).json({ error: 'Invalid code' });

    user.twoFactorEnabled = true;
    await user.save();
    res.json({ message: '2FA enabled successfully' });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

exports.refresh = async (req, res) => {
  try {
    const { refreshToken } = req.body;
    if (!refreshToken) return res.status(401).json({ error: 'Refresh token required' });

    const decoded = jwt.verify(refreshToken, process.env.JWT_REFRESH_SECRET);
    const user = await User.findByPk(decoded.id);
    if (!user) return res.status(401).json({ error: 'User not found' });

    const tokens = generateTokens(user);
    res.json(tokens);
  } catch (err) {
    res.status(401).json({ error: 'Invalid refresh token' });
  }
};