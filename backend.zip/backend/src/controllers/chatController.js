const Message = require('../models/Message');
const User = require('../models/User');
const Room = require('../models/Room');
const { uploadToS3 } = require('../utils/upload');

exports.getMessages = async (req, res) => {
  try {
    const { roomId, recipientId } = req.query;
    let where = {};
    if (roomId) where.roomId = roomId;
    if (recipientId) {
      where = {
        [Op.or]: [
          { senderId: req.userId, recipientId },
          { senderId: recipientId, recipientId: req.userId }
        ]
      };
    }
    const messages = await Message.findAll({
      where,
      include: [{ model: User, as: 'sender', attributes: ['id', 'username', 'avatar'] }],
      order: [['createdAt', 'ASC']],
      limit: 50
    });
    res.json(messages);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

exports.sendMessage = async (req, res) => {
  try {
    const { content, type, roomId, recipientId } = req.body;
    let fileUrl = null;
    if (req.file) {
      fileUrl = await uploadToS3(req.file);
    }
    const message = await Message.create({
      content,
      type: type || (req.file ? 'file' : 'text'),
      fileUrl,
      roomId: roomId || 'global',
      recipientId,
      senderId: req.userId
    });
    const populated = await Message.findByPk(message.id, {
      include: [{ model: User, as: 'sender', attributes: ['id', 'username', 'avatar'] }]
    });
    // ارسال رویداد از طریق Socket.io انجام می‌شود
    res.status(201).json(populated);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

exports.createRoom = async (req, res) => {
  try {
    const { name, description, type, password } = req.body;
    const room = await Room.create({
      name,
      description,
      type,
      password: password ? await bcrypt.hash(password, 10) : null,
      ownerId: req.userId
    });
    res.status(201).json(room);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};