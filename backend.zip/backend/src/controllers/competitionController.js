exports.vote = async (req, res) => {
  try {
    const { participantId } = req.body;
    const competition = await Competition.findByPk(req.params.id);
    if (!competition || competition.status !== 'active') {
      return res.status(400).json({ error: 'Competition not active' });
    }
    const participant = await CompetitionParticipant.findOne({
      where: { CompetitionId: competition.id, UserId: participantId }
    });
    if (!participant) {
      return res.status(404).json({ error: 'Participant not found' });
    }
    participant.votes += 1;
    await participant.save();

    // ارسال رویداد به روزرسانی آرا
    req.io.to(`competition_${competition.id}`).emit('voteUpdate', {
      participantId,
      votes: participant.votes
    });

    res.json({ message: 'Vote recorded' });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};