const User = require('../models/User');
const Report = require('../models/Report');

// تعلیق کاربر به مدت ۲۴ ساعت
exports.suspendUser = async (req, res) => {
  try {
    const { userId, hours } = req.body; // hours = 24
    if (!userId || !hours) {
      return res.status(400).json({ error: 'userId و hours الزامی هستند' });
    }

    const user = await User.findByPk(userId);
    if (!user) {
      return res.status(404).json({ error: 'کاربر یافت نشد' });
    }

    const suspendUntil = new Date();
    suspendUntil.setHours(suspendUntil.getHours() + hours);
    user.suspendedUntil = suspendUntil;
    await user.save();

    // ثبت در گزارش (اختیاری)
    // اگر این اقدام از طریق یک گزارش انجام شده، می‌توانید گزارش را به‌روزرسانی کنید
    const { reportId } = req.body;
    if (reportId) {
      const report = await Report.findByPk(reportId);
      if (report) {
        report.status = 'resolved';
        report.adminAction = `کاربر به مدت ${hours} ساعت تعلیق شد.`;
        await report.save();
      }
    }

    res.json({
      message: `کاربر تا ${suspendUntil.toLocaleString('fa-IR')} تعلیق شد.`
    });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

// رفع تعلیق کاربر
exports.unsuspendUser = async (req, res) => {
  try {
    const { userId } = req.body;
    const user = await User.findByPk(userId);
    if (!user) {
      return res.status(404).json({ error: 'کاربر یافت نشد' });
    }
    user.suspendedUntil = null;
    await user.save();
    res.json({ message: 'تعلیق کاربر لغو شد.' });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};