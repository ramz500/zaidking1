const { DataTypes } = require('sequelize');
const sequelize = require('../config/database');

const Message = sequelize.define('Message', {
  content: {
    type: DataTypes.TEXT,
    allowNull: false
  },
  type: {
    type: DataTypes.ENUM('text', 'image', 'audio', 'file', 'gif'),
    defaultValue: 'text'
  },
  fileUrl: DataTypes.STRING,
  roomId: {
    type: DataTypes.STRING,
    defaultValue: 'global'
  },
  recipientId: {
    type: DataTypes.INTEGER,
    allowNull: true // برای پیام خصوصی
  }
});

Message.belongsTo(User, { as: 'sender', foreignKey: 'senderId' });
Message.belongsTo(User, { as: 'recipient', foreignKey: 'recipientId' });

module.exports = Message;