const { DataTypes } = require('sequelize');
const sequelize = require('../config/database');

const CompetitionParticipant = sequelize.define('CompetitionParticipant', {
  votes: {
    type: DataTypes.INTEGER,
    defaultValue: 0
  }
});

module.exports = CompetitionParticipant;