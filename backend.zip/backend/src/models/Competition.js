const { DataTypes } = require('sequelize');
const sequelize = require('../config/database');

const Competition = sequelize.define('Competition', {
  title: {
    type: DataTypes.STRING,
    allowNull: false
  },
  description: DataTypes.TEXT,
  endTime: {
    type: DataTypes.DATE,
    allowNull: false
  },
  criteria: {
    type: DataTypes.ENUM('votes', 'reactions', 'interactions'),
    defaultValue: 'votes'
  },
  status: {
    type: DataTypes.ENUM('pending', 'active', 'ended'),
    defaultValue: 'pending'
  },
  winnerId: {
    type: DataTypes.INTEGER,
    allowNull: true
  },
  createdById: {
    type: DataTypes.INTEGER,
    allowNull: false
  }
});

Competition.belongsTo(User, { as: 'creator' });
Competition.belongsTo(User, { as: 'winner' });
Competition.belongsToMany(User, { through: 'CompetitionParticipants', as: 'participants' });

module.exports = Competition;