const { DataTypes } = require('sequelize');
const sequelize = require('../config/database');

const Badge = sequelize.define('Badge', {
  name: DataTypes.STRING,
  description: DataTypes.TEXT,
  icon: DataTypes.STRING,
  criteria: DataTypes.STRING // مثلاً "شرکت در ۱۰ مسابقه"
});

Badge.belongsToMany(User, { through: 'UserBadges' });
module.exports = Badge;