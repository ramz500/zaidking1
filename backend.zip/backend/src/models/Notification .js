const { DataTypes } = require('sequelize');
const sequelize = require('../config/database');

const Notification = sequelize.define('Notification', {
  type: {
    type: DataTypes.ENUM('friend_request', 'message', 'competition_win', 'system'),
    allowNull: false
  },
  content: {
    type: DataTypes.TEXT,
    allowNull: false
  },
  isRead: {
    type: DataTypes.BOOLEAN,
    defaultValue: false
  },
  userId: {
    type: DataTypes.INTEGER,
    allowNull: false
  },
  senderId: {
    type: DataTypes.INTEGER,
    allowNull: true
  },
  link: {
    type: DataTypes.STRING,
    allowNull: true // لینک به صفحه مربوطه
  }
});

Notification.belongsTo(User, { as: 'user' });
Notification.belongsTo(User, { as: 'sender' });

module.exports = Notification;