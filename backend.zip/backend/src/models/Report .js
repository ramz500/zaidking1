const { DataTypes } = require('sequelize');
const sequelize = require('../config/database');
const User = require('./User');

const Report = sequelize.define('Report', {
  reason: {
    type: DataTypes.TEXT,
    allowNull: false
  },
  status: {
    type: DataTypes.ENUM('pending', 'reviewed', 'resolved'),
    defaultValue: 'pending'
  },
  targetType: {
    type: DataTypes.ENUM('user', 'message', 'room', 'competition'),
    allowNull: false
  },
  targetId: {
    type: DataTypes.INTEGER,
    allowNull: false
  },
  reporterId: {
    type: DataTypes.INTEGER,
    allowNull: false,
    references: {
      model: User,
      key: 'id'
    }
  },
  adminAction: {
    type: DataTypes.TEXT, // توضیح اقدام انجام شده توسط ادمین
    allowNull: true
  }
});

Report.belongsTo(User, { as: 'reporter', foreignKey: 'reporterId' });
Report.belongsTo(User, { as: 'target', foreignKey: 'targetId', constraints: false }); // targetId می‌تواند به کاربر یا موارد دیگر اشاره کند

module.exports = Report;