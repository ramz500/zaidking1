const { DataTypes } = require('sequelize');
const sequelize = require('../config/database');

const Room = sequelize.define('Room', {
  name: {
    type: DataTypes.STRING,
    allowNull: false
  },
  description: DataTypes.TEXT,
  type: {
    type: DataTypes.ENUM('public', 'private', 'voice'),
    defaultValue: 'public'
  },
  password: {
    type: DataTypes.STRING, // در صورت رمزگذاری
    allowNull: true
  },
  ownerId: {
    type: DataTypes.INTEGER,
    allowNull: false
  },
  isVoice: {
    type: DataTypes.BOOLEAN,
    defaultValue: false
  }
});

Room.belongsTo(User, { as: 'owner' });
Room.belongsToMany(User, { through: 'RoomMembers', as: 'members' });

module.exports = Room;