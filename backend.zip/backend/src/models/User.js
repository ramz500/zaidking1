const { DataTypes } = require('sequelize');
const sequelize = require('../config/database');
const bcrypt = require('bcrypt');
const { generateRecoveryCode } = require('../utils/helpers');
const { v4: uuidv4 } = require('uuid');

const User = sequelize.define('User', {
  username: {
    type: DataTypes.STRING(20),
    allowNull: false,
    unique: true,
    validate: { len: [3, 20] }
  },
  password: {
    type: DataTypes.STRING,
    allowNull: false
  },
  recoveryCode: {
    type: DataTypes.STRING,
    allowNull: false,
    unique: true
  },
  email: {
    type: DataTypes.STRING,
    allowNull: true,
    unique: true,
    validate: { isEmail: true }
  },
  avatar: {
    type: DataTypes.STRING,
    defaultValue: 'default.png'
  },
  bio: {
    type: DataTypes.TEXT,
    defaultValue: ''
  },
  level: {
    type: DataTypes.INTEGER,
    defaultValue: 1
  },
  xp: {
    type: DataTypes.INTEGER,
    defaultValue: 0
  },
  status: {
    type: DataTypes.ENUM('online', 'offline', 'away'),
    defaultValue: 'offline'
  },
  lastSeen: {
    type: DataTypes.DATE,
    defaultValue: DataTypes.NOW
  },
  twoFactorEnabled: {
    type: DataTypes.BOOLEAN,
    defaultValue: false
  },
  twoFactorSecret: {
    type: DataTypes.STRING,
    allowNull: true
  },
  role: {
    type: DataTypes.ENUM('user', 'admin'),
    defaultValue: 'user'
  },
  // فیلدهای جدید
  suspendedUntil: {
    type: DataTypes.DATE,
    allowNull: true // اگر null باشد حساب فعال است
  },
  referralCode: {
    type: DataTypes.STRING,
    unique: true
  },
  referredBy: {
    type: DataTypes.INTEGER,
    allowNull: true,
    references: {
      model: 'Users', // نام مدل (باید با نام جدول مطابقت داشته باشد)
      key: 'id'
    }
  },
  inviteCount: {
    type: DataTypes.INTEGER,
    defaultValue: 0
  }
}, {
  hooks: {
    beforeCreate: async (user) => {
      // هش کردن رمز عبور
      user.password = await bcrypt.hash(user.password, 10);
      // تولید کد بازیابی
      user.recoveryCode = generateRecoveryCode();
      // تولید کد دعوت یکتا
      if (!user.referralCode) {
        user.referralCode = uuidv4().substring(0, 8).toUpperCase();
      }
    },
    beforeUpdate: async (user) => {
      if (user.changed('password')) {
        user.password = await bcrypt.hash(user.password, 10);
      }
    }
  }
});

// متد بررسی تعلیق حساب
User.prototype.isSuspended = function() {
  return this.suspendedUntil && this.suspendedUntil > new Date();
};

User.prototype.comparePassword = function(password) {
  return bcrypt.compare(password, this.password);
};

module.exports = User;