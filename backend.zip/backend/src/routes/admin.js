const express = require('express');
const router = express.Router();
const auth = require('../middleware/auth');
const admin = require('../middleware/admin');
const adminController = require('../controllers/adminController');

// تعلیق کاربر
router.post('/suspend', auth, admin, adminController.suspendUser);

// رفع تعلیق کاربر
router.post('/unsuspend', auth, admin, adminController.unsuspendUser);

module.exports = router;