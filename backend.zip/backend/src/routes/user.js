// ... سایر requireها
const userController = require('../controllers/userController');

// حذف حساب کاربری
router.delete('/me', auth, userController.deleteAccount);