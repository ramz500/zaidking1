const express = require('express');
const auth = require('../middleware/auth');
const Report = require('../models/Report');

const router = express.Router();

router.post('/', auth, async (req, res) => {
  try {
    const { reason, targetType, targetId } = req.body;
    const report = await Report.create({
      reason,
      targetType,
      targetId,
      reporterId: req.userId
    });
    res.status(201).json(report);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// دریافت گزارش‌ها (فقط برای ادمین)
router.get('/', auth, async (req, res) => {
  if (req.userRole !== 'admin') return res.status(403).json({ error: 'Forbidden' });
  const reports = await Report.findAll({ include: ['reporter'] });
  res.json(reports);
});

router.put('/:id', auth, async (req, res) => {
  if (req.userRole !== 'admin') return res.status(403).json({ error: 'Forbidden' });
  const report = await Report.findByPk(req.params.id);
  if (!report) return res.status(404).json({ error: 'Report not found' });
  report.status = req.body.status;
  await report.save();
  res.json(report);
});

module.exports = router;