const express = require('express');
const router = express.Router();
const auth = require('../middleware/auth');
const checkSuspended = require('../middleware/checkSuspended'); // middleware جدید
const chatController = require('../controllers/chatController');
const { upload } = require('../utils/upload'); // برای آپلود فایل

// دریافت پیام‌ها (با قابلیت فیلتر بر اساس roomId یا recipientId)
router.get('/messages', auth, chatController.getMessages);

// ارسال پیام (متن، تصویر، فایل و ...) – نیاز به بررسی تعلیق
router.post(
  '/messages',
  auth,
  checkSuspended, // کاربران مسدود شده نمی‌توانند پیام ارسال کنند
  upload.single('file'), // آپلود فایل (اختیاری)
  chatController.sendMessage
);

// ایجاد اتاق جدید
router.post('/rooms', auth, chatController.createRoom);

// دریافت لیست اتاق‌ها
router.get('/rooms', auth, chatController.getRooms);

// دریافت اطلاعات یک اتاق
router.get('/rooms/:roomId', auth, chatController.getRoom);

// پیوستن به اتاق (با رمز در صورت وجود)
router.post('/rooms/:roomId/join', auth, chatController.joinRoom);

// ترک اتاق
router.post('/rooms/:roomId/leave', auth, chatController.leaveRoom);

// دریافت اعضای اتاق
router.get('/rooms/:roomId/members', auth, chatController.getRoomMembers);

// ارسال پیام خصوصی (معمولاً از طریق WebSocket انجام می‌شود، اما می‌توان endpoint HTTP هم داشت)
// اینجا صرفاً برای نمایش اضافه شده است
router.post('/private', auth, checkSuspended, chatController.sendPrivateMessage);

module.exports = router;