const WorkerManager = require('../mediasoup/WorkerManager');

// ... کد قبلی ...

socket.on('joinVoiceRoom', async ({ roomId }, callback) => {
  try {
    let room = WorkerManager.getRoom(roomId);
    if (!room) {
      const router = await WorkerManager.createRoom(roomId);
      room = WorkerManager.getRoom(roomId);
    }
    const { router } = room;

    // ایجاد transport برای کاربر
    const transport = await router.createWebRtcTransport({
      listenIps: [{ ip: '0.0.0.0', announcedIp: 'your_public_ip' }], // در تولید آدرس عمومی سرور
      enableUdp: true,
      enableTcp: true,
      preferUdp: true,
    });

    room.peers.set(socket.userId, { transport, producers: [] });

    callback({
      routerRtpCapabilities: router.rtpCapabilities,
      transportOptions: {
        id: transport.id,
        iceParameters: transport.iceParameters,
        iceCandidates: transport.iceCandidates,
        dtlsParameters: transport.dtlsParameters,
      },
    });
  } catch (err) {
    callback({ error: err.message });
  }
});

socket.on('connectTransport', async ({ transportId, dtlsParameters }, callback) => {
  const room = [...WorkerManager.rooms.values()].find(r => r.peers.has(socket.userId));
  if (!room) return callback({ error: 'Not in a room' });
  const peer = room.peers.get(socket.userId);
  const transport = peer.transport;
  await transport.connect({ dtlsParameters });
  callback({ success: true });
});

socket.on('produce', async ({ kind, rtpParameters }, callback) => {
  const room = [...WorkerManager.rooms.values()].find(r => r.peers.has(socket.userId));
  if (!room) return callback({ error: 'Not in a room' });
  const peer = room.peers.get(socket.userId);
  const transport = peer.transport;
  const producer = await transport.produce({ kind, rtpParameters });
  peer.producers.push(producer);

  // اطلاع به سایر کاربران در اتاق
  room.peers.forEach((otherPeer, otherId) => {
    if (otherId !== socket.userId) {
      io.to(onlineUsers.get(otherId)).emit('newProducer', {
        producerId: producer.id,
        userId: socket.userId,
        kind,
      });
    }
  });

  callback({ id: producer.id });
});

socket.on('consume', async ({ producerId, rtpCapabilities }, callback) => {
  const room = [...WorkerManager.rooms.values()].find(r => r.peers.has(socket.userId));
  if (!room) return callback({ error: 'Not in a room' });
  const peer = room.peers.get(socket.userId);
  const transport = peer.transport;

  if (!room.router.canConsume({ producerId, rtpCapabilities })) {
    return callback({ error: 'Cannot consume' });
  }

  const consumer = await transport.consume({
    producerId,
    rtpCapabilities,
    paused: false,
  });

  callback({
    id: consumer.id,
    producerId,
    kind: consumer.kind,
    rtpParameters: consumer.rtpParameters,
  });
});

socket.on('leaveVoiceRoom', async () => {
  const room = [...WorkerManager.rooms.values()].find(r => r.peers.has(socket.userId));
  if (room) {
    const peer = room.peers.get(socket.userId);
    peer.producers.forEach(p => p.close());
    peer.transport.close();
    room.peers.delete(socket.userId);
    // اطلاع به دیگران
    room.peers.forEach((_, otherId) => {
      io.to(onlineUsers.get(otherId)).emit('peerLeft', { userId: socket.userId });
    });
  }
});