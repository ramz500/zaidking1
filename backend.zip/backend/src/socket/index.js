// تابع کمکی برای ارسال اعلان به کاربر خاص
const sendNotification = async (userId, notificationData) => {
  const socketId = onlineUsers.get(userId);
  if (socketId) {
    io.to(socketId).emit('notification', notificationData);
  }
  // ذخیره در دیتابیس
  await Notification.create({ ...notificationData, userId });
};