const User = require('../models/User');

module.exports = async (req, res, next) => {
  try {
    const user = await User.findByPk(req.userId);
    if (!user) {
      return res.status(401).json({ error: 'کاربر یافت نشد' });
    }
    if (user.isSuspended()) {
      const until = user.suspendedUntil.toLocaleString('fa-IR');
      return res.status(403).json({
        error: `حساب شما تا ${until} مسدود می‌باشد.`,
        suspendedUntil: user.suspendedUntil
      });
    }
    next();
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};