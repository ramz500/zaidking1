const { Op } = require('sequelize');
const Competition = require('../models/Competition');
const User = require('../models/User');
const { sendNotification } = require('../socket');

exports.checkEndedCompetitions = async (io) => {
  const competitions = await Competition.findAll({
    where: {
      status: 'active',
      endTime: { [Op.lt]: new Date() }
    }
  });

  for (const comp of competitions) {
    let winnerId = null;
    if (comp.criteria === 'votes') {
      const participants = await comp.getParticipants({ join: { model: CompetitionParticipant } });
      const sorted = participants.sort((a, b) => b.CompetitionParticipant.votes - a.CompetitionParticipant.votes);
      winnerId = sorted[0]?.id;
    }
    // سایر معیارها مشابه

    comp.winnerId = winnerId;
    comp.status = 'ended';
    await comp.save();

    if (winnerId) {
      // اعلام برنده به همه
      io.emit('winner-announcement', {
        competitionId: comp.id,
        winner: (await User.findByPk(winnerId, { attributes: ['id', 'username'] })),
        title: comp.title
      });

      // ارسال اعلان به برنده
      await sendNotification(winnerId, {
        type: 'competition_win',
        content: `تبریک! شما در مسابقه "${comp.title}" برنده شدید.`,
        link: `/competitions/${comp.id}`
      });
    }
  }
};