require('dotenv').config();
const express = require('express');
const http = require('http');
const socketIo = require('socket.io');
const cors = require('cors');
const helmet = require('helmet');
const compression = require('compression');
const morgan = require('morgan');
const path = require('path');

const { sequelize } = require('./models');
const { setupSocket } = require('./socket');

const authRoutes = require('./routes/auth');
const userRoutes = require('./routes/user');
const chatRoutes = require('./routes/chat');
const competitionRoutes = require('./routes/competition');
const reportRoutes = require('./routes/report');
const adminRoutes = require('./routes/admin');

const { errorHandler } = require('./middleware/errorHandler');
const { rateLimiter } = require('./middleware/rateLimiter');

const cron = require('node-cron');
const { checkEndedCompetitions } = require('./jobs/competitionJob');

const app = express();
const server = http.createServer(app);

/* ================= CORS ================= */

const allowedOrigin = process.env.FRONTEND_URL || "*";

const io = socketIo(server, {
  cors: {
    origin: allowedOrigin,
    credentials: true
  }
});

app.use(helmet());
app.use(cors({
  origin: allowedOrigin,
  credentials: true
}));

app.use(compression());
app.use(express.json({ limit: '10mb' }));
app.use(morgan(process.env.NODE_ENV === 'production' ? 'combined' : 'dev'));

/* ================= RATE LIMIT ================= */

app.use('/api', rateLimiter);

/* ================= ROUTES ================= */

app.use('/api/auth', authRoutes);
app.use('/api/users', userRoutes);
app.use('/api/chat', chatRoutes);
app.use('/api/competitions', competitionRoutes);
app.use('/api/reports', reportRoutes);
app.use('/api/admin', adminRoutes);

/* ================= STATIC ================= */

app.use('/uploads', express.static(path.join(__dirname, '../uploads')));
app.use(express.static(path.join(__dirname, '../public')));

app.get('*', (req, res, next) => {
  if (!req.path.startsWith('/api')) {
    return res.sendFile(path.join(__dirname, '../public/index.html'));
  }
  next();
});

/* ================= SOCKET ================= */

setupSocket(io);

/* ================= ERROR ================= */

app.use(errorHandler);

/* ================= SERVER ================= */

const PORT = process.env.PORT || 5000;

async function startServer() {
  try {
    await sequelize.authenticate();
    console.log("✅ Database connected");

    await sequelize.sync();

    server.listen(PORT, () => {
      console.log(`🚀 Server running on port ${PORT}`);
    });

  } catch (err) {
    console.error("❌ Database error:", err.message);

    server.listen(PORT, () => {
      console.log(`⚠ Server running without DB on port ${PORT}`);
    });
  }
}

startServer();

/* ================= CRON ================= */

cron.schedule('* * * * *', async () => {
  try {
    await checkEndedCompetitions(io);
  } catch (error) {
    console.error("Cron error:", error.message);
  }
});