const mediasoup = require('mediasoup');

class WorkerManager {
  constructor() {
    this.workers = [];
    this.rooms = new Map(); // roomId -> { router, peers }
  }

  async init() {
    const worker = await mediasoup.createWorker({
      rtcMinPort: 40000,
      rtcMaxPort: 49999,
    });
    worker.on('died', () => {
      console.error('mediasoup worker died, exiting...');
      process.exit(1);
    });
    this.workers.push(worker);
    return worker;
  }

  async createRoom(roomId) {
    const worker = this.workers[0]; // برای سادگی از اولین worker استفاده می‌کنیم
    const router = await worker.createRouter({
      mediaCodecs: [
        {
          kind: 'audio',
          mimeType: 'audio/opus',
          clockRate: 48000,
          channels: 2,
        },
      ],
    });
    this.rooms.set(roomId, { router, peers: new Map() });
    return router;
  }

  getRoom(roomId) {
    return this.rooms.get(roomId);
  }
}

module.exports = new WorkerManager();