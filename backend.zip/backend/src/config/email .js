const nodemailer = require('nodemailer');

// ایجاد transporter
const transporter = nodemailer.createTransport({
  host: process.env.EMAIL_HOST,
  port: process.env.EMAIL_PORT,
  secure: process.env.EMAIL_SECURE === 'true', // true برای 465
  auth: {
    user: process.env.EMAIL_USER,
    pass: process.env.EMAIL_PASS
  }
});

const adminEmail = process.env.ADMIN_EMAIL;

/**
 * ارسال ایمیل گزارش به ادمین
 * @param {Object} reportData - داده‌های گزارش
 */
const sendReportEmail = async (reportData) => {
  const { reason, targetType, targetId, reporterUsername, targetUsername } = reportData;

  const mailOptions = {
    from: `"ShadowVerse Reports" <${process.env.EMAIL_USER}>`,
    to: adminEmail,
    subject: `🚨 گزارش جدید: ${targetType} #${targetId}`,
    html: `
      <div dir="rtl" style="font-family: Tahoma, Arial, sans-serif; background: #1a1a1a; color: #fff; padding: 20px;">
        <h2 style="color: #ff4444;">گزارش تخلف جدید</h2>
        <p><strong>گزارش‌دهنده:</strong> ${reporterUsername}</p>
        <p><strong>نوع هدف:</strong> ${targetType}</p>
        <p><strong>شناسه هدف:</strong> ${targetId}</p>
        <p><strong>نام کاربری هدف:</strong> ${targetUsername || 'نامشخص'}</p>
        <p><strong>دلیل:</strong> ${reason}</p>
        <p>لطفاً وارد پنل مدیریت شوید و اقدام کنید.</p>
        <a href="${process.env.ADMIN_PANEL_URL}/reports" style="display: inline-block; background: #ff4444; color: #fff; padding: 10px 20px; text-decoration: none; border-radius: 5px;">مشاهده گزارش‌ها</a>
      </div>
    `
  };

  try {
    await transporter.sendMail(mailOptions);
    console.log('Report email sent to admin');
  } catch (error) {
    console.error('Error sending report email:', error);
  }
};

module.exports = { sendReportEmail };